package model.utils;

public class Page {
  public String name;
  public String displayName;

  public Page(String name, String displayName) {
    this.name = name;
    this.displayName = displayName;
  }
}
