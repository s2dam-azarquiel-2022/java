$("#logo").click(() => { $("#logo-form").submit(); });
